// var objAjax = {
//     url: "",
//     data: {},
//     nombreFuncion: ""
// }

function AjaxGetAll(obj){    
    var url = obj.url    
    $.ajax({
        method: "GET",
        url: url,
        dataType: 'json',
        data: obj.data
    })
    .done(function( result ) {
        obj.nombreFuncion(result);        
    });
}

function AjaxPost(obj){           
    var url = obj.url   
    $.ajax({
        method: "POST",
        url: url,        
        contentType: "application/json",   
        dataType: 'json',
        data: JSON.stringify(obj.data)        
    })
    .done(function( result ) {        
        obj.nombreFuncion(result);        
    });
}

function AjaxGetItem(obj){    
    var url = obj.url + "/" + obj.data.id;   
    $.ajax({
        method: "GET",
        url: url,
        dataType: 'json'        
    })
    .done(function( result ) {
        obj.nombreFuncion(result);                
    });
}

function AjaxDeleteItem(obj){           
    var url = obj.url + "/" + obj.data.id;   
    $.ajax({
        method: "DELETE",
        url: url,
        dataType: 'json'    
    })
    .done(function( result ) {        
        obj.nombreFuncion(result);       
    });
}

function AjaxPutItem(id, obj){  
    var url = obj.url + "/" + id;                
    $.ajax({
        method: "PUT",
        url: url,        
        contentType: "application/json",   
        dataType: 'json',
        data: JSON.stringify(obj.data)        
    })
    .done(function( result ) {        
        obj.nombreFuncion(result);       
    });
}